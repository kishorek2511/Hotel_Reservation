package com.wipro.dao;


import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.wipro.model.HotelReservations;

@Repository
public class HotelReservationsDAO {
	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public HotelReservations getHotelReservations(int id) {
		Session session = this.sessionFactory.getCurrentSession();
		HotelReservations hotelReservation = (HotelReservations) session.get(HotelReservations.class, new Integer(id));
		return hotelReservation;
	}
	public List<HotelReservations> getAllDetails() {
		Session session = this.sessionFactory.getCurrentSession();
		List<HotelReservations> countryList = session.createQuery("from hotels").list();
		return countryList;
	}
}
