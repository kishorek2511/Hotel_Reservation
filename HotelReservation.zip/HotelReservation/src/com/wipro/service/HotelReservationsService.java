package com.wipro.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.dao.HotelReservationsDAO;
import com.wipro.model.HotelReservations;

@Service("HotelReservationsService")
public class HotelReservationsService {

	@Autowired
	HotelReservationsDAO hotelReservationsDAO;
	
	@Transactional
	public List<HotelReservations> getAllDetails() {
		return hotelReservationsDAO.getAllDetails();
	}
	
	@Transactional
	public HotelReservations getHotelReservations(int id) {
	  return hotelReservationsDAO.getHotelReservations(id);
	}
	
}
