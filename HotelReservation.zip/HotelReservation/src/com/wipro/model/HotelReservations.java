package com.wipro.model;
import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * This is our model class and it corresponds to Country table in database
 */
@Entity
@Table(name="hotels")
public class HotelReservations {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	
	@Column(name="City")
	String City;	
	
	@Column(name="Hotel")
	String Hotel;
	
	@Column(name="Dat")
	String Dat;
	
	
	public HotelReservations() {
		super();
	}
	public HotelReservations(int i, String City,String Hotel, String Dat) {
		super();
		this.id = i;
		this.City = City;
		this.Hotel=Hotel;
		this.Dat=Dat;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getHotel() {
		return Hotel;
	}

	public void setHotel(String hotel) {
		Hotel = hotel;
	}

	public String getDat() {
		return Dat;
	}

	public void setDat(String dat) {
		Dat = dat;
	}


}
