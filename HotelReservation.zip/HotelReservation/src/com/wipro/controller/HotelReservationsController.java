package com.wipro.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.model.HotelReservations;
import com.wipro.service.HotelReservationsService;

public class HotelReservationsController {
	
	@Autowired
	HotelReservationsService hotelReservationsService;
	
	@RequestMapping(value="/getAllDetails",method = RequestMethod.GET, headers = "Accept=application/json")
	  public String showRegister(Model model) {
	  
	    return "checkAvailability";
	  }

	
	@RequestMapping(value = "/bookingProcess", method = RequestMethod.POST, headers = "Accept=application/json")
	public String processForm(@ModelAttribute HotelReservations hotelReservations)  {
		return "roomtype";
	}
}
